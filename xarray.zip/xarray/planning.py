"""Plan distributed reductions and execute MPI collectives."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Hashable, Iterable, Mapping
from types import EllipsisType
from typing import TYPE_CHECKING, Any, Literal

import numpy as np
from mpi4py import MPI

import xarray as xr

from .cartesian import get_cartesian_topology
from .chunks import prune_chunk_info
from .common import (
    _MPI_REDUCIBLE_KINDS,
    CHECK_COLLECTIVE_AGREEMENT,
    PlanEntry,
    _mpi_representable,
    _op_name,
    _partial_dtype,
)
from .meta import choose_partition_dim, set_mpi_meta, strip_mpi_meta

if TYPE_CHECKING:
    from ..mpi.runtime import MPIRuntime


class ReductionPlanningMixin:
    """Plan distributed reductions and execute MPI collectives.

    The host class must provide ``self._runtime``. Concrete reduction mixins
    use these helpers for collective agreement, exchange, and metadata repair.
    """

    _runtime: MPIRuntime

    # -- collective planning -------------------------------------------------

    @staticmethod
    def _normalize_dim(
        value: xr.Dataset | xr.DataArray,
        dim: str | Iterable[Hashable] | EllipsisType | None,
    ) -> tuple[Any, tuple[Hashable, ...]]:
        """Normalize a reduction dimension specification."""
        if not isinstance(value, (xr.DataArray, xr.Dataset)):
            raise TypeError(
                "MPI xarray operations require an xarray DataArray or Dataset."
            )
        if dim is None or dim is ...:
            return dim, tuple(value.dims)
        if isinstance(dim, str):
            return dim, (dim,)
        dims = tuple(dim)
        return dims, dims

    @staticmethod
    def _skipna_enabled(dtype: np.dtype[Any], skipna: bool | None) -> bool:
        """Return the effective dtype-aware ``skipna`` setting."""
        if skipna is not None:
            return skipna
        return dtype.kind in "fc"

    @staticmethod
    def _check_reducible(dtype: np.dtype[Any], operation: str) -> None:
        """Validate that a dtype supports the requested MPI reduction."""
        if operation in ("any", "all"):
            return
        if dtype.kind not in _MPI_REDUCIBLE_KINDS:
            raise TypeError(f"Unsupported MPI xarray dtype: {dtype}.")
        if not _mpi_representable(dtype.str):
            # float16 and long double have a reducible NumPy kind but no
            # predefined MPI datatype. Rejecting them here raises on every
            # rank before any collective, instead of failing inside
            # Allreduce with MPI_ERR_TYPE once buffers are already posted.
            raise TypeError(
                f"Unsupported MPI xarray dtype: {dtype}. "
                + "No predefined MPI datatype represents it."
            )
        if operation in ("min", "max") and dtype.kind == "c":
            name = "minimum" if operation == "min" else "maximum"
            raise TypeError(f"MPI {name} is not defined for complex xarray data.")

    @staticmethod
    def _local_reduction_meta(
        meta: Mapping[str, Any] | None,
        dims: tuple[Hashable, ...],
        *,
        partition_dim: Hashable | Literal["auto"] | None,
    ) -> Mapping[str, Any] | None:
        """Return metadata when a reduction remains rank-local.

        A multi-dimensional partition stays local only when *none* of its
        partition dimensions are being reduced -- reducing away just one
        of several partition axes still requires a (sub-)communicator
        collective for any variable that owns that axis.
        """
        if meta is None or any(dim in dims for dim in meta["dims"]):
            return None
        if partition_dim not in (None, "auto"):
            raise ValueError(
                "partition_dim can name a new dimension only after the active "
                + "partition dimension has been reduced away."
            )
        return meta

    @staticmethod
    def _finish_local_reduction(
        result: xr.Dataset | xr.DataArray, *, old_meta: Mapping[str, Any]
    ) -> xr.Dataset | xr.DataArray:
        """Restore metadata after a rank-local reduction."""
        dims = tuple(dim for dim in old_meta["dims"] if dim in result.dims)
        if not dims:
            return strip_mpi_meta(result)
        set_mpi_meta(
            result,
            dim=dims,
            global_size={dim: int(old_meta["global_sizes"][dim]) for dim in dims},
            start={dim: int(old_meta["starts"][dim]) for dim in dims},
            stop={dim: int(old_meta["stops"][dim]) for dim in dims},
            chunk_info=prune_chunk_info(old_meta["chunk_info"], result),
            cart=old_meta.get("cart"),
        )
        return result

    def _agree(self, signature: tuple[Any, ...]) -> None:
        """Verify that all ranks entered the same reduction plan."""
        if not CHECK_COLLECTIVE_AGREEMENT or self._runtime.comm.size == 1:
            return
        digest = hashlib.blake2b(repr(signature).encode(), digest_size=16).digest()
        self._runtime.raise_if_error(
            None,
            "MPI xarray reduction planning",
            signature=("xarray_reduction_plan", digest),
        )

    def _plan(
        self,
        value: xr.Dataset | xr.DataArray,
        dims: tuple[Hashable, ...],
        meta: Mapping[str, Any] | None,
        *,
        operation: str,
    ) -> tuple[PlanEntry, ...]:
        """Build and validate the rank-independent reduction plan.

        For each variable, classifies the active partition dimensions
        (``meta["dims"]``) into those the variable *owns* (present in its
        own dims) and those it is merely *replicated* along (a partition
        dimension of the object as a whole that this particular variable
        does not vary over -- e.g. a ``(lat,)`` mask under a ``(lat, lon)``
        partition). ``comm_axes`` is the set of partition dimensions this
        variable's reduction must communicate over: the owned dimensions
        actually being reduced, plus every replicated dimension (whose
        duplicate copies must be merged into the collective group so they
        are not silently omitted, and whose count is recorded in
        ``replica_count`` so :meth:`_comm_reduce` can undo the resulting
        over-counting of an ``MPI.SUM``). A variable with no active
        partition dimensions at all (the one-dimensional case when it
        lacks the sole partition dim, exactly as before) gets an empty
        ``comm_axes`` and is untouched by this generalization.
        """
        if isinstance(value, xr.DataArray):
            items: tuple[tuple[Hashable, xr.DataArray], ...] = ((value.name, value),)
        else:
            items = tuple((name, value[name]) for name in value.data_vars)

        partition_dims: tuple[Hashable, ...] = () if meta is None else meta["dims"]
        grid_shape_by_dim: dict[Hashable, int] = {}
        if meta is not None and "cart" in meta:
            grid_shape_by_dim = dict(
                zip(meta["dims"], meta["cart"]["grid_shape"], strict=True)
            )

        entries = []
        for name, variable in items:
            variable_dims = tuple(dim for dim in dims if dim in variable.dims)
            if variable_dims:
                self._check_reducible(variable.dtype, operation)

            owned = tuple(dim for dim in partition_dims if dim in variable.dims)
            replicated = tuple(
                dim for dim in partition_dims if dim not in variable.dims
            )
            reduced = tuple(dim for dim in variable_dims if dim in owned)
            comm_axes = (
                frozenset(reduced) | frozenset(replicated) if reduced else frozenset()
            )
            replica_count = (
                math.prod(grid_shape_by_dim.get(dim, 1) for dim in replicated)
                if reduced and replicated
                else 1
            )
            if replica_count != 1 and operation == "prod":
                # A duplicated contribution inflates a sum by an exact,
                # exactly-undoable integer factor (divide it back out); it
                # inflates a product by raising it to the replica_count-th
                # power instead, which has no numerically reliable general
                # inverse (an n-th root is ill-defined for negative or
                # complex values and imprecise for float ones). Rather than
                # silently return a wrong answer, this combination is
                # explicitly unsupported for now.
                raise NotImplementedError(
                    f"prod() cannot yet reduce variable {name!r}: it is "
                    + f"replicated along {tuple(str(d) for d in replicated)!r} "
                    + "under this multi-dimensional partition, and undoing a "
                    + "product's duplication has no exact general inverse "
                    + "(unlike sum/count/mean, which divide it back out "
                    + "exactly). Reduce the replicated dimension(s) first, or "
                    + "use sum()/mean() instead."
                )

            entries.append(
                PlanEntry(
                    name=name,
                    dims=variable_dims,
                    distributed=bool(comm_axes),
                    dtype=variable.dtype,
                    shape=tuple(
                        (
                            str(dim),
                            # A surviving dimension's *local* size is only
                            # rank-invariant (and therefore safe for the
                            # cross-rank agreement hash below) when it is
                            # not itself a partition dimension. Once more
                            # than one dimension can be partitioned, a
                            # surviving dimension can easily be a different
                            # partition axis than the one being reduced
                            # right now (e.g. reducing "lat" while "lon" is
                            # also partitioned) -- every rank then legally
                            # owns a different local "lon" extent, so its
                            # *global* size (identical everywhere) must be
                            # used instead.
                            int(
                                meta["global_sizes"][dim]
                                if meta is not None and dim in partition_dims
                                else value.sizes[dim]
                            ),
                        )
                        for dim in variable.dims
                        if dim not in variable_dims
                    ),
                    comm_axes=comm_axes,
                    replica_count=int(replica_count),
                )
            )

        plan = tuple(entries)
        self._agree(
            (
                operation,
                tuple(str(dim) for dim in dims),
                tuple(
                    (
                        str(entry.name),
                        tuple(str(dim) for dim in entry.dims),
                        entry.distributed,
                        str(entry.dtype),
                        entry.shape,
                        tuple(sorted(str(d) for d in entry.comm_axes)),
                        entry.replica_count,
                    )
                    for entry in plan
                ),
            )
        )
        return plan

    def _resolve_comm(
        self, meta: Mapping[str, Any] | None, comm_axes: Iterable[Hashable]
    ) -> MPI.Comm:
        """Return the communicator a plan entry's collective should use.

        The full communicator for the default one-dimensional case (no
        ``meta["cart"]``, or only one active partition dimension) --
        identical to every collective call before this generalization, so
        that path pays no extra cost. Otherwise, the cached
        :class:`~.cartesian.CartesianTopology` sub-communicator that spans
        exactly ``comm_axes`` (see :meth:`.cartesian.CartesianTopology.sub_comm`).
        """
        axes = frozenset(comm_axes)
        if meta is None or not axes or "cart" not in meta or len(meta["dims"]) <= 1:
            return self._runtime.comm
        topology = get_cartesian_topology(
            self._runtime.comm, meta["dims"], meta["global_sizes"]
        )
        return topology.sub_comm(axes)

    @staticmethod
    def _guarded(function: Any) -> tuple[Any, BaseException | None]:
        """Run a local operation and defer any exception for synchronization."""
        try:
            return function(), None
        except BaseException as exc:
            return None, exc

    # -- collective primitives -----------------------------------------------

    def _comm_reduce(
        self,
        value: xr.DataArray | None,
        op: MPI.Op,
        *,
        expect_dtype: np.dtype[Any] | None = None,
        error: BaseException | None = None,
        phase: str = "MPI xarray reduction buffer preparation",
        comm: MPI.Comm | None = None,
        replica_count: int = 1,
    ) -> xr.DataArray:
        """Combine a validated DataArray buffer across ranks.

        Parameters
        ----------
        comm : mpi4py.MPI.Comm, optional
            Communicator to reduce over. Defaults to the full runtime
            communicator, exactly as before this parameter existed --
            pass a :meth:`ReductionPlanningMixin._resolve_comm` result for
            a partial (sub-communicator) collective under a
            multi-dimensional partition.
        replica_count : int, optional
            Size of a replicated-axis subgroup folded into ``comm`` (see
            :attr:`~.common.PlanEntry.replica_count`). Only meaningful for
            ``op=MPI.SUM``: the raw Allreduce total then counts each
            logical contribution ``replica_count`` times over, so it is
            divided back out here, exactly, before returning. Ignored
            (default 1) for every other op, since MIN/MAX/LAND/LOR are
            idempotent under duplication and need no correction.
        """
        send: np.ndarray[Any, Any] | None = None
        if error is None:
            try:
                if value is None:
                    raise AssertionError("MPI xarray reduction buffer is missing.")
                send = np.asarray(value.values)
                if expect_dtype is not None and send.dtype != np.dtype(expect_dtype):
                    send = send.astype(expect_dtype)
                if not send.flags.c_contiguous:
                    send = np.ascontiguousarray(send)
                if send.dtype.kind not in _MPI_REDUCIBLE_KINDS:
                    raise TypeError(f"Unsupported MPI xarray dtype: {send.dtype}.")
                if not _mpi_representable(send.dtype.str):
                    raise TypeError(
                        f"Unsupported MPI xarray dtype: {send.dtype}. "
                        + "No predefined MPI datatype represents it."
                    )
            except BaseException as exc:
                error = exc
                send = None

        signature = (
            None
            if send is None
            else (
                _op_name(op),
                send.dtype.str,
                tuple(int(length) for length in send.shape),
            )
        )
        self._runtime.raise_if_error(error, phase, signature, comm=comm)
        if send is None or value is None:
            raise AssertionError("MPI xarray reduction buffer is missing.")

        recv = self._exchange(send, op, comm=comm)
        result = value.copy(data=recv)
        if replica_count != 1 and op == MPI.SUM:
            # Every one of the replica_count duplicate copies contributed to
            # the raw sum above, so it is exactly replica_count times too
            # large. Integer dtypes divide exactly (each duplicate is a
            # bit-identical copy, so the raw sum is an exact multiple);
            # floating dtypes use true division for the same reason plain
            # division, not floor division, is correct for a value that
            # need not itself be an integer multiple of anything.
            if result.dtype.kind in "iu":
                result = result // replica_count
            else:
                result = result / replica_count
        return result

    def _exchange(
        self, send: np.ndarray[Any, Any], op: MPI.Op, *, comm: MPI.Comm | None = None
    ) -> np.ndarray[Any, Any]:
        """All-reduce a validated contiguous NumPy buffer over ``comm``.

        ``comm`` defaults to the full runtime communicator, unchanged from
        before this parameter existed.
        """
        recv = np.empty(send.shape, dtype=send.dtype)
        active_comm = self._runtime.comm if comm is None else comm
        active_comm.Allreduce(send, recv, op=op)
        return recv

    def _count(
        self,
        value: xr.DataArray,
        dims: tuple[Hashable, ...],
        *,
        comm: MPI.Comm | None = None,
        replica_count: int = 1,
    ) -> xr.DataArray:
        """Count valid values globally across the requested dimensions."""
        count: xr.DataArray | None = None
        error: BaseException | None = None
        try:
            count = value.count(dim=dims, keep_attrs=False)
        except BaseException as exc:
            error = exc
        return self._comm_reduce(
            count,
            MPI.SUM,
            expect_dtype=_partial_dtype(value.dtype.str, "count", None),
            error=error,
            phase="MPI xarray count reduction",
            comm=comm,
            replica_count=replica_count,
        )

    @staticmethod
    def _dataset_result(
        value: xr.Dataset,
        dims: tuple[Hashable, ...],
        variables: Mapping[Hashable, xr.DataArray],
    ) -> xr.Dataset:
        """Rebuild a Dataset from reduced data variables."""
        reduced = set(dims)
        coords = {
            name: coord
            for name, coord in value.coords.items()
            if not reduced & set(coord.dims)
        }
        return xr.Dataset(dict(variables), coords=coords, attrs=dict(value.attrs))

    @staticmethod
    def _repartition_candidates(plan: tuple[PlanEntry, ...]) -> frozenset[Hashable]:
        """Return dimensions eligible for post-reduction repartition."""
        return frozenset(
            dim for entry in plan if entry.distributed for dim, _ in entry.shape
        )

    def _finish(
        self,
        result: xr.Dataset | xr.DataArray,
        *,
        old_meta: Mapping[str, Any] | None,
        partition_dim: Hashable | Literal["auto"] | None,
        auto_candidates: frozenset[Hashable],
    ) -> xr.Dataset | xr.DataArray:
        """Finalize metadata and optional repartition after a reduction."""
        result = strip_mpi_meta(result)
        old_dims: tuple[Hashable, ...] = () if old_meta is None else old_meta["dims"]
        remaining_dims = tuple(dim for dim in old_dims if dim in result.dims)
        partition_removed = old_meta is not None and not remaining_dims

        if partition_dim is None:
            return result

        if partition_dim == "auto" and remaining_dims:
            # At least one, but not every, previous partition dimension
            # survived the reduction (only possible with more than one
            # partition dimension to begin with -- with exactly one, this
            # is unreachable, since removing "the" partition dimension is
            # exactly what made this call require MPI communication in the
            # first place). Every rank already owns a valid, unmoved,
            # contiguous slice along whatever survived, so reattach
            # metadata for that surviving subset directly instead of
            # scattering through repartition() below. The Cartesian
            # topology descriptor is only carried forward when every one
            # of its axes survived unchanged; otherwise a fresh, smaller
            # topology (for just the surviving axes) is built lazily, on
            # demand, the next time a multi-axis collective needs one.
            assert old_meta is not None  # remaining_dims is empty otherwise
            cart = (
                old_meta.get("cart") if len(remaining_dims) == len(old_dims) else None
            )
            set_mpi_meta(
                result,
                dim=remaining_dims,
                global_size={
                    dim: int(old_meta["global_sizes"][dim]) for dim in remaining_dims
                },
                start={dim: int(old_meta["starts"][dim]) for dim in remaining_dims},
                stop={dim: int(old_meta["stops"][dim]) for dim in remaining_dims},
                chunk_info=prune_chunk_info(old_meta["chunk_info"], result),
                cart=cart,
            )
            return result

        target = partition_dim
        if partition_dim == "auto":
            if not partition_removed:
                return result
            sizes = {
                dim: length
                for dim, length in result.sizes.items()
                if dim in auto_candidates
            }
            if not any(int(length) > 1 for length in sizes.values()):
                return result
            target = choose_partition_dim(
                sizes, self._runtime.comm.size, rank=self._runtime.comm.rank
            )
        elif partition_dim not in auto_candidates:
            raise ValueError(
                f"partition_dim={partition_dim!r} is not a dimension of any "
                + "variable that required an MPI collective in this reduction; "
                + "an untouched, replicated variable's own dimension cannot be "
                + "used as the new partition dimension."
            )

        chunk_info = (
            prune_chunk_info(old_meta["chunk_info"], result)
            if old_meta is not None
            else {}
        )
        return self.repartition(result, target, chunk_info=chunk_info)
