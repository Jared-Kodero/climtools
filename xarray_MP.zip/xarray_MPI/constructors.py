"""Module-level constructors for :class:`~.core.MPIXarray`.

No :class:`~.core.MPIXarray` exists yet for these to be a method on: each
builds data from scratch (or from a root-owned/external value) and returns
the first wrapped :class:`~.core.MPIXarray`. All take the runtime explicitly
rather than relying on any ambient/bound runtime.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
import xarray as xr

from ..mpi.runtime import MPIRuntime, mpi
from .core import MPIXarray, _unwrap
from .netcdf import io as netcdf_io
from .ops import _MPIXarrayOps

if TYPE_CHECKING:
    from collections.abc import Callable, Hashable, Iterable, Mapping, Sequence
    from os import PathLike
    from typing import Literal

    from mpi4py.MPI import Intracomm


def open_dataset(
    filename_or_obj: Any,
    mpi_runtime: MPIRuntime | Intracomm,
    *,
    partition_dim: Hashable | Literal["auto"] = "auto",
    chunks: Any = None,
    log_partitions: bool = True,
    **kwargs: Any,
) -> MPIXarray:
    """Open a Dataset lazily and distribute one dimension across MPI ranks.

    Parameters
    ----------
    filename_or_obj : str, path-like, file-like, or list of these
        Input accepted by ``xarray.open_dataset``/``xarray.open_mfdataset``.
        A wildcard string or a list/tuple triggers multi-file loading.
    mpi_runtime : MPIRuntime or mpi4py.MPI.Intracomm
        Runtime whose communicator the result is bound to.
    partition_dim : Hashable or {"auto"}, optional
        Dimension to distribute. "auto" selects the longest dimension.
    chunks : int, dict, "auto" or None, optional
        Passed unchanged to xarray.
    log_partitions : bool, optional
        Print one aligned table showing which global interval each rank received.
    **kwargs : Any
        Additional arguments passed unchanged to ``xarray.open_dataset``/
        ``xarray.open_mfdataset`` (e.g. ``engine``, ``decode_times``,
        ``concat_dim``, ``combine``, ``preprocess``, ``parallel``).

    Returns
    -------
    MPIXarray
        Lazy rank-local Dataset with ``.meta`` set.
    """
    if not isinstance(mpi_runtime, MPIRuntime):
        mpi_runtime = MPIRuntime(mpi_runtime)
    data = _MPIXarrayOps(mpi_runtime).open_dataset(
        filename_or_obj,
        partition_dim=partition_dim,
        chunks=chunks,
        log_partitions=log_partitions,
        **kwargs,
    )
    return MPIXarray(data, mpi_runtime)


def create_dataarray(
    runtime: MPIRuntime,
    fill: Callable[[int, int], Any],
    dims: Sequence[Hashable],
    *,
    shape: Sequence[int] | Mapping[Hashable, int] | None = None,
    dim: Hashable | int = 0,
    dtype: Any = np.float64,
    coords: Mapping[Hashable, Any] | None = None,
    name: Hashable | None = None,
    attrs: Mapping[str, Any] | None = None,
    log_partitions: bool = False,
) -> MPIXarray:
    """Create a distributed DataArray from a rank-local fill function.

    Parameters
    ----------
    runtime : MPIRuntime
        Runtime whose communicator the result is bound to.
    fill : callable
        Function called as ``fill(start, stop)`` for this rank's bounds.
    dims : sequence of Hashable
        Dimension names.
    shape : sequence of int, mapping, or None, optional
        Global dimension sizes. Missing sizes may be inferred from ``coords``.
    dim : Hashable or int, optional
        Dimension or axis to partition.
    dtype : Any, optional
        Data type returned by ``fill``.
    coords : mapping, optional
        Coordinates passed to ``xarray.DataArray``.
    name : Hashable, optional
        DataArray name.
    attrs : mapping, optional
        DataArray attributes.
    log_partitions : bool, optional
        Log the resulting rank layout.

    Returns
    -------
    MPIXarray
        Lazy rank-local DataArray with ``.meta`` set.
    """
    data = _MPIXarrayOps(runtime).create_dataarray(
        fill,
        dims,
        shape=shape,
        dim=dim,
        dtype=dtype,
        coords=coords,
        name=name,
        attrs=attrs,
        log_partitions=log_partitions,
    )
    return MPIXarray(data, runtime)


def create_dataset(
    runtime: MPIRuntime,
    data_vars: Mapping[
        Hashable, xr.DataArray | tuple[Sequence[Hashable], Callable[[int, int], Any]]
    ],
    sizes: Mapping[Hashable, int] | None = None,
    *,
    dim: Hashable,
    dtype: Any = np.float64,
    coords: Mapping[Hashable, Any] | None = None,
    attrs: Mapping[str, Any] | None = None,
    log_partitions: bool = True,
) -> MPIXarray:
    """Create a distributed Dataset from rank-local variables.

    Parameters
    ----------
    runtime : MPIRuntime
        Runtime whose communicator the result is bound to.
    data_vars : mapping
        Variables as DataArrays or ``(dims, fill)`` pairs. Partitioned fill
        functions receive ``(start, stop)``; unpartitioned fills take no arguments.
    sizes : mapping, optional
        Global dimension sizes. Missing sizes may be inferred from ``coords``.
    dim : Hashable
        Dimension to partition.
    dtype : Any or mapping, optional
        Default or per-variable fill dtype.
    coords : mapping, optional
        Coordinates passed to ``xarray.Dataset``.
    attrs : mapping, optional
        Dataset attributes.
    log_partitions : bool, optional
        Log the resulting rank layout.

    Returns
    -------
    MPIXarray
        Lazy rank-local Dataset with ``.meta`` set.
    """
    data = _MPIXarrayOps(runtime).create_dataset(
        data_vars,
        sizes,
        dim=dim,
        dtype=dtype,
        coords=coords,
        attrs=attrs,
        log_partitions=log_partitions,
    )
    return MPIXarray(data, runtime)


def distribute(
    value: MPIXarray | xr.Dataset | xr.DataArray | None,
    runtime: MPIRuntime,
    dim: Hashable | Literal["auto"] = "auto",
    *,
    root: int = 0,
    chunk_info: Mapping[str, int] | None = None,
    log_partitions: bool = False,
) -> MPIXarray:
    """Distribute a root-owned xarray object across MPI ranks.

    Parameters
    ----------
    value : MPIXarray, xarray.Dataset, xarray.DataArray, or None
        Complete object on ``root``; non-root ranks must pass None.
    runtime : MPIRuntime
        Runtime whose communicator the result is bound to.
    dim : Hashable or {"auto"}, optional
        Partition dimension. "auto" selects the largest dimension.
    root : int, optional
        Rank that owns ``value``.
    chunk_info : mapping of str to int, optional
        Effective chunk-size hints.
    log_partitions : bool, optional
        Log the resulting rank layout.

    Returns
    -------
    MPIXarray
        Rank-local slice with ``.meta`` set.
    """
    data = _MPIXarrayOps(runtime).distribute(
        _unwrap(value),
        dim,
        root=root,
        chunk_info=chunk_info,
        log_partitions=log_partitions,
    )
    return MPIXarray(data, runtime)


def to_netcdf(
    data: MPIXarray | xr.Dataset | xr.DataArray,
    file: str | PathLike[str],
    mpi_runtime: MPIRuntime | Intracomm = mpi,
    unlimited_dim: str | Iterable[str] | None = None,
    partition_dim: str | None = None,
    *,
    parallel: bool = False,
    batch_size: int = 24,
    format: str = "NETCDF4",
    shuffle: bool = True,
    zlib: bool = True,
    complevel: int = 4,
    show_progress: bool = True,
    stdout: Any = None,
    chunks: Mapping[str, Iterable[int]] | None = None,
    hints: str | None = None,
    nofill: bool = True,
    allow_serial: bool = False,
) -> None:
    """Write a Dataset or DataArray to NetCDF.

    Serial output is written incrementally along an unlimited dimension. In
    parallel mode, an object carrying ``mpi_meta`` is already distributed and
    every rank writes its existing local slab directly. Otherwise rank 0 owns
    the complete object and the parallel writer distributes partitioned data.

    A distributed ``data`` first has write-time chunk metadata attached
    internally (the engine's ``attach_save_chunks`` step -- computed on
    rank 0 from distribution metadata and broadcast, no data materialized;
    a no-op for a non-distributed object). This is no longer a separate
    method to call beforehand: it is purely an implementation detail of
    writing, not something callers need to reason about.

    Parameters
    ----------
    data : MPIXarray, xarray.Dataset, or xarray.DataArray
        Object to write. An :class:`MPIXarray` is unwrapped so
        :func:`~.netcdf.io.to_netcdf` sees its ``mpi_meta`` in ``.attrs``.
    file : str or os.PathLike
        Output path.
    mpi_runtime : MPIRuntime, optional
        Runtime whose communicator backs a parallel write. Defaults to the
        package-wide :data:`~..mpi.runtime.mpi` instance.
    unlimited_dim : str or iterable of str, optional
        Dimension or dimensions made unlimited.
    partition_dim : str, optional
        MPI partition dimension. For an already distributed object this must
        agree with ``mpi_meta["dim"]``.
    parallel : bool, default False
        Use MPI-parallel NetCDF-4 output.
    batch_size : int, default 24
        Number of slices written per serial append.
    format : str, default "NETCDF4"
        NetCDF format for serial output.
    shuffle : bool, default True
        Apply the HDF5 shuffle filter.
    zlib : bool, default True
        Apply zlib compression.
    complevel : int, default 4
        Compression level from 0 through 9.
    show_progress : bool, default True
        Display serial write progress.
    stdout : Any, optional
        Serial progress output stream.
    chunks : mapping of str to iterable of int, optional
        Explicit NetCDF variable chunk shapes.
    hints : str, optional
        Semicolon-separated MPI-IO hints in ``key=value`` form.
    nofill : bool, default True
        Disable NetCDF pre-filling during parallel initialization.
    allow_serial : bool, default False
        Permit the parallel writer with one MPI rank.

    Returns
    -------
    None
    """
    runtime = (
        mpi_runtime if isinstance(mpi_runtime, MPIRuntime) else MPIRuntime(mpi_runtime)
    )
    prepared = _MPIXarrayOps(runtime).attach_save_chunks(_unwrap(data))
    netcdf_io.to_netcdf(
        prepared,
        file,
        runtime,
        unlimited_dim,
        partition_dim,
        parallel=parallel,
        batch_size=batch_size,
        format=format,
        shuffle=shuffle,
        zlib=zlib,
        complevel=complevel,
        show_progress=show_progress,
        stdout=stdout,
        chunks=chunks,
        hints=hints,
        nofill=nofill,
        allow_serial=allow_serial,
    )
