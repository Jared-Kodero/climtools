"""``MPIXarray``: a rank-local xarray object bound to its MPI distribution.

:class:`MPIXarray` is the public interface: a wrapper around one rank-local
``xarray.Dataset``/``xarray.DataArray`` (``.data``) and its MPI distribution
metadata (``.meta``), bound to an :class:`~..mpi.runtime.MPIRuntime`. It is
built by :func:`~.constructors.open_dataset`,
:func:`~.constructors.create_dataset`,
:func:`~.constructors.create_dataarray`, or
:func:`~.constructors.distribute` -- never directly from raw input --
and every method on it runs on ``self.data`` and returns a new, re-wrapped
:class:`MPIXarray`. Attribute access not defined on the wrapper (``.values``,
``.dims``, ``.sizes``, ``.coords``, ...) passes through to ``self.data``.

``mpi_meta`` (the dict :mod:`.meta` uses to track which global slice of a
dimension this rank owns) only ever lives in ``xarray`` ``.attrs`` while a
call is in flight through the underlying engine (:class:`~.ops._MPIXarrayOps`),
which is the only thing that reads/writes it there; the moment a call
returns, it is popped out of ``.attrs`` and kept solely on
``MPIXarray.meta``, so ``self.data`` a caller holds is always plain,
unannotated xarray data.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import xarray as xr

from .meta import _assign_meta, get_mpi_meta, strip_mpi_meta
from .ops import _MPIXarrayOps

if TYPE_CHECKING:
    from collections.abc import Callable, Hashable, Iterable, Mapping
    from types import EllipsisType
    from typing import Literal

    import numpy as np

    from ..mpi.runtime import MPIRuntime

#: Sentinel distinguishing "no fill value given" from a genuine ``other=None``
#: in :meth:`MPIXarray.where`.
_WHERE_UNSET = object()

#: Explicit allowlist of read-only xarray properties ``MPIXarray.__getattr__``
#: forwards to ``self.data``. Deliberately a fixed list, not a
#: ``callable(...)`` check: a heuristic based on callability would pass
#: through non-callable-but-still-wrong things (e.g. accessor namespaces)
#: just as easily as it would block a legitimate future property, and is
#: no easier to audit than this list is.
_SAFE_PASSTHROUGH_ATTRS: frozenset[str] = frozenset(
    {
        "attrs",
        "chunks",
        "chunksizes",
        "coords",
        "data_vars",
        "dims",
        "dtype",
        "dtypes",
        "encoding",
        "indexes",
        "name",
        "nbytes",
        "ndim",
        "shape",
        "size",
        "sizes",
        "T",
        "values",
        "variables",
    }
)


class MPIXarray:
    """A distributed xarray object bound to an MPI runtime.

    Wraps a rank-local ``xarray.Dataset``/``xarray.DataArray`` (``.data``)
    together with its MPI distribution metadata (``.meta``). ``.data`` never
    carries ``mpi_meta`` in its ``.attrs``: metadata is reattached only for
    the duration of one call into the underlying engine and popped back out
    into ``.meta`` immediately on return (see :meth:`_prepare`).

    Every method below runs the corresponding :class:`~.ops._MPIXarrayOps`
    implementation on ``self.data`` and returns a new :class:`MPIXarray`
    with ``.meta`` updated. Attribute access not defined here passes
    through to ``self.data`` via ``__getattr__`` *only* for the names in
    :data:`_SAFE_PASSTHROUGH_ATTRS` (``.values``, ``.dims``, ``.sizes``,
    ``.coords``, ``.attrs``, ...): a fixed, explicit allowlist of
    read-only xarray properties, not a heuristic. Any other name -- in
    particular a plain xarray *method* we have not wrapped, such as
    ``.median()``, ``.where()``, ``.rolling()`` -- raises
    ``AttributeError`` rather than silently running xarray's plain,
    rank-local implementation; use ``.data.<name>(...)`` explicitly for
    that. ``repr()`` is ``repr(self.data)``.

    Build an instance with :func:`~.constructors.open_dataset`,
    :func:`~.constructors.create_dataset`,
    :func:`~.constructors.create_dataarray`, or
    :func:`~.constructors.distribute` -- not by constructing
    :class:`MPIXarray` directly on raw input.

    Parameters
    ----------
    data : xarray.Dataset or xarray.DataArray
        Rank-local object. If it carries ``mpi_meta`` (e.g. straight off the
        underlying engine), that metadata is popped into ``.meta`` and
        stripped from ``.attrs`` immediately.
    runtime : MPIRuntime
        Runtime whose communicator backs every distributed operation.
    meta : dict or None, optional
        Distribution metadata to use as-is, bypassing the ``.attrs`` pop
        above. Internal callers that already computed ``meta`` pass it here;
        leave as None otherwise.
    """

    def __init__(
        self,
        data: xr.Dataset | xr.DataArray,
        runtime: MPIRuntime,
        meta: dict[str, Any] | None = None,
    ) -> None:
        if meta is None:
            meta = get_mpi_meta(data)
            if meta is not None:
                data = strip_mpi_meta(data)
        self.data = data
        self.meta = meta
        self._runtime = runtime
        self._ops = _MPIXarrayOps(runtime)

    def __repr__(self) -> str:
        return repr(self.data)

    def __getattr__(self, name: str) -> Any:
        if name == "data":
            raise AttributeError(name)
        if name not in _SAFE_PASSTHROUGH_ATTRS:
            raise AttributeError(
                f"{name!r} is not an MPI-aware MPIXarray method or a "
                + f"recognized passthrough property. Use `.data.{name}` (or "
                + f"`.data.{name}(...)`) for xarray's plain, rank-local "
                + f"implementation, or add an MPI-aware `{name}` to "
                + "MPIXarray if it needs to be distribution-safe."
            )
        return getattr(self.data, name)

    def _prepare(self) -> xr.Dataset | xr.DataArray:
        """Return ``self.data`` with ``self.meta`` reattached to ``.attrs``.

        The underlying engine (:class:`~.ops._MPIXarrayOps`) reads
        distribution metadata from ``value.attrs`` (see
        :func:`~.meta.get_mpi_meta`), but ``self.data`` deliberately never
        carries it (see class docstring). This reattaches ``self.meta`` to a
        shallow copy -- ``self.data`` itself is left untouched -- for the
        duration of a single engine call; the copy is discarded once that
        call's result is re-wrapped.

        Returns
        -------
        xarray.Dataset or xarray.DataArray
            ``self.data``, unchanged if ``self.meta`` is None, otherwise a
            shallow copy carrying ``self.meta`` in ``.attrs["mpi_meta"]``.
        """
        if self.meta is None:
            return self.data
        prepared = self.data.copy(deep=False)
        _assign_meta(prepared, self.meta)
        return prepared

    def _dispatch(self, name: str, *args: Any, **kwargs: Any) -> Any:
        """Call ``_MPIXarrayOps.<name>`` on ``self.data`` and wrap the result.

        Parameters
        ----------
        name : str
            Method name on :class:`~.ops._MPIXarrayOps` to invoke.
        *args : Any
            Positional arguments forwarded to that method.
        **kwargs : Any
            Keyword arguments forwarded to that method.

        Returns
        -------
        MPIXarray or Any
            The method's result, wrapped by :func:`_finalize`.
        """
        method = getattr(self._ops, name)
        return _finalize(method(self._prepare(), *args, **kwargs), self._runtime)

    # -- IO: (re)distribution of an existing object --------------------------

    def repartition(
        self,
        dim: Hashable | Literal["auto"] = "auto",
        *,
        chunk_info: Mapping[str, int] | None = None,
        log_partitions: bool = False,
    ) -> MPIXarray:
        """Partition a replicated object across MPI ranks.

        Parameters
        ----------
        dim : Hashable or {"auto"}, optional
            New partition dimension. "auto" selects the largest dimension.
        chunk_info : mapping of str to int, optional
            Effective chunk-size hints.
        log_partitions : bool, optional
            Log the resulting rank layout.

        Returns
        -------
        MPIXarray
            Rank-local slice with ``.meta`` set.
        """
        return self._dispatch(
            "repartition", dim, chunk_info=chunk_info, log_partitions=log_partitions
        )

    # -- Indexing --------------------------------------------------------------

    def isel(
        self,
        indexers: Mapping[Any, Any] | None = None,
        *,
        partition_dim: Hashable | Literal["auto"] | None = None,
        **indexers_kwargs: Any,
    ) -> MPIXarray:
        """Index with global integer coordinates on the partition dimension.

        Parameters
        ----------
        indexers : mapping, optional
            Integer indexers using global coordinates on the partition dimension.
        partition_dim : Hashable or {"auto"} or None, optional
            Dimension to scatter a resulting single-element partition dimension
            across, when a slice indexer collapses it to length one.
        **indexers_kwargs : Any
            Additional indexers passed by dimension name.

        Returns
        -------
        MPIXarray
            Indexed object with ``.meta`` updated.
        """
        return self._dispatch(
            "isel", indexers, partition_dim=partition_dim, **indexers_kwargs
        )

    def isel_scalar(
        self,
        dim: Hashable,
        index: int,
        other_indexers: Mapping[Any, Any] | None = None,
    ) -> MPIXarray:
        """Select one global integer index from the partition dimension.

        Parameters
        ----------
        dim : Hashable
            Partition dimension.
        index : int
            Global integer index.
        other_indexers : mapping, optional
            Additional local ``isel`` indexers.

        Returns
        -------
        MPIXarray
            Replicated selected slice.
        """
        return self._dispatch("isel_scalar", dim, index, other_indexers or {})

    def sel(
        self,
        indexers: Mapping[Any, Any] | None = None,
        method: str | None = None,
        tolerance: Any = None,
        drop: bool = False,
        *,
        partition_dim: Hashable | Literal["auto"] | None = None,
        **indexers_kwargs: Any,
    ) -> MPIXarray:
        """Index with global coordinate labels on the partition dimension.

        Parameters
        ----------
        indexers : mapping, optional
            Label indexers using global semantics on the partition dimension.
        method : str, optional
            Inexact matching method passed to xarray.
        tolerance : Any, optional
            Maximum distance for inexact matches.
        drop : bool, optional
            Drop selected coordinate variables.
        partition_dim : Hashable or {"auto"} or None, optional
            Dimension to scatter a resulting single-element partition dimension
            across, when a label slice collapses it to length one.
        **indexers_kwargs : Any
            Additional indexers passed by dimension name.

        Returns
        -------
        MPIXarray
            Indexed object with ``.meta`` updated. A scalar selection on the
            partition dimension is replicated on every rank.
        """
        return self._dispatch(
            "sel",
            indexers,
            method,
            tolerance,
            drop,
            partition_dim=partition_dim,
            **indexers_kwargs,
        )

    def sel_scalar(
        self,
        dim: Hashable,
        label: Any,
        other_indexers: Mapping[Any, Any] | None = None,
        *,
        method: str | None = None,
        tolerance: Any = None,
        drop: bool = False,
    ) -> MPIXarray:
        """Select one global label from the partition dimension.

        Parameters
        ----------
        dim : Hashable
            Partition dimension.
        label : Any
            Global coordinate label.
        other_indexers : mapping, optional
            Additional local ``sel`` indexers.
        method : str, optional
            Inexact matching method passed to xarray.
        tolerance : Any, optional
            Maximum distance for inexact matches.
        drop : bool, optional
            Drop selected coordinate variables.

        Returns
        -------
        MPIXarray
            Replicated selected slice.
        """
        return self._dispatch(
            "sel_scalar",
            dim,
            label,
            other_indexers or {},
            method=method,
            tolerance=tolerance,
            drop=drop,
        )

    # -- Reductions --------------------------------------------------------

    def sum(
        self,
        dim: str | Iterable[Hashable] | EllipsisType | None = None,
        *,
        skipna: bool | None = None,
        min_count: int | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Sum over one or more dimensions.

        Parameters
        ----------
        dim : str, iterable of Hashable, ..., or None, optional
            Dimensions to reduce. None or ``...`` reduces all dimensions.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        min_count : int or None, optional
            Minimum number of valid values required.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.
        partition_dim : Hashable or {"auto"} or None, optional
            Partition placement after reducing the active partition dimension.

        Returns
        -------
        MPIXarray
            Reduced object with ``.meta`` updated.
        """
        return self._dispatch(
            "sum",
            dim,
            skipna=skipna,
            min_count=min_count,
            keep_attrs=keep_attrs,
            partition_dim=partition_dim,
        )

    def prod(
        self,
        dim: str | Iterable[Hashable] | EllipsisType | None = None,
        *,
        skipna: bool | None = None,
        min_count: int | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Multiply over one or more dimensions.

        Parameters
        ----------
        dim : str, iterable of Hashable, ..., or None, optional
            Dimensions to reduce. None or ``...`` reduces all dimensions.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        min_count : int or None, optional
            Minimum number of valid values required.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.
        partition_dim : Hashable or {"auto"} or None, optional
            Partition placement after reducing the active partition dimension.

        Returns
        -------
        MPIXarray
            Reduced object with ``.meta`` updated.
        """
        return self._dispatch(
            "prod",
            dim,
            skipna=skipna,
            min_count=min_count,
            keep_attrs=keep_attrs,
            partition_dim=partition_dim,
        )

    def mean(
        self,
        dim: str | Iterable[Hashable] | EllipsisType | None = None,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Compute the mean over one or more dimensions.

        Parameters
        ----------
        dim : str, iterable of Hashable, ..., or None, optional
            Dimensions to reduce. None or ``...`` reduces all dimensions.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.
        partition_dim : Hashable or {"auto"} or None, optional
            Partition placement after reducing the active partition dimension.

        Returns
        -------
        MPIXarray
            Reduced object with ``.meta`` updated.
        """
        return self._dispatch(
            "mean",
            dim,
            skipna=skipna,
            keep_attrs=keep_attrs,
            partition_dim=partition_dim,
        )

    def min(
        self,
        dim: str | Iterable[Hashable] | EllipsisType | None = None,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Compute the minimum over one or more dimensions.

        Parameters
        ----------
        dim : str, iterable of Hashable, ..., or None, optional
            Dimensions to reduce. None or ``...`` reduces all dimensions.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.
        partition_dim : Hashable or {"auto"} or None, optional
            Partition placement after reducing the active partition dimension.

        Returns
        -------
        MPIXarray
            Reduced object with ``.meta`` updated.
        """
        return self._dispatch(
            "min",
            dim,
            skipna=skipna,
            keep_attrs=keep_attrs,
            partition_dim=partition_dim,
        )

    def max(
        self,
        dim: str | Iterable[Hashable] | EllipsisType | None = None,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Compute the maximum over one or more dimensions.

        Parameters
        ----------
        dim : str, iterable of Hashable, ..., or None, optional
            Dimensions to reduce. None or ``...`` reduces all dimensions.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.
        partition_dim : Hashable or {"auto"} or None, optional
            Partition placement after reducing the active partition dimension.

        Returns
        -------
        MPIXarray
            Reduced object with ``.meta`` updated.
        """
        return self._dispatch(
            "max",
            dim,
            skipna=skipna,
            keep_attrs=keep_attrs,
            partition_dim=partition_dim,
        )

    def any(
        self,
        dim: str | Iterable[Hashable] | EllipsisType | None = None,
        *,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Return whether any value is true over the requested dimensions.

        Parameters
        ----------
        dim : str, iterable of Hashable, ..., or None, optional
            Dimensions to reduce. None or ``...`` reduces all dimensions.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.
        partition_dim : Hashable or {"auto"} or None, optional
            Partition placement after reducing the active partition dimension.

        Returns
        -------
        MPIXarray
            Logical OR over the requested dimensions, with ``.meta`` updated.
        """
        return self._dispatch(
            "any", dim, keep_attrs=keep_attrs, partition_dim=partition_dim
        )

    def all(
        self,
        dim: str | Iterable[Hashable] | EllipsisType | None = None,
        *,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Return whether every value is true over the requested dimensions.

        Parameters
        ----------
        dim : str, iterable of Hashable, ..., or None, optional
            Dimensions to reduce. None or ``...`` reduces all dimensions.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.
        partition_dim : Hashable or {"auto"} or None, optional
            Partition placement after reducing the active partition dimension.

        Returns
        -------
        MPIXarray
            Logical AND over the requested dimensions, with ``.meta`` updated.
        """
        return self._dispatch(
            "all", dim, keep_attrs=keep_attrs, partition_dim=partition_dim
        )

    def first(
        self,
        dim: str,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Select the first valid value along one dimension.

        Parameters
        ----------
        dim : str
            Dimension to pick a position along.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.
        partition_dim : Hashable or {"auto"} or None, optional
            Partition placement after reducing the active partition dimension.

        Returns
        -------
        MPIXarray
            Selected object with ``.meta`` updated.
        """
        return self._dispatch(
            "first",
            dim,
            skipna=skipna,
            keep_attrs=keep_attrs,
            partition_dim=partition_dim,
        )

    def last(
        self,
        dim: str,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Select the last valid value along one dimension.

        Parameters
        ----------
        dim : str
            Dimension to pick a position along.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.
        partition_dim : Hashable or {"auto"} or None, optional
            Partition placement after reducing the active partition dimension.

        Returns
        -------
        MPIXarray
            Selected object with ``.meta`` updated.
        """
        return self._dispatch(
            "last",
            dim,
            skipna=skipna,
            keep_attrs=keep_attrs,
            partition_dim=partition_dim,
        )

    # -- Statistics ----------------------------------------------------------

    def var(
        self,
        dim: str | Iterable[Hashable] | EllipsisType | None = None,
        *,
        skipna: bool | None = None,
        ddof: int = 0,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Compute the variance over one or more dimensions.

        Parameters
        ----------
        dim : str, iterable of Hashable, ..., or None, optional
            Dimensions to reduce. None or ``...`` reduces all dimensions.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        ddof : int, optional
            Delta degrees of freedom; the divisor is ``N - ddof``.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.
        partition_dim : Hashable or {"auto"} or None, optional
            Partition placement after reducing the active partition dimension.

        Returns
        -------
        MPIXarray
            Reduced object with ``.meta`` updated.
        """
        return self._dispatch(
            "var",
            dim,
            skipna=skipna,
            ddof=ddof,
            keep_attrs=keep_attrs,
            partition_dim=partition_dim,
        )

    def std(
        self,
        dim: str | Iterable[Hashable] | EllipsisType | None = None,
        *,
        skipna: bool | None = None,
        ddof: int = 0,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Compute the standard deviation over one or more dimensions.

        Parameters
        ----------
        dim : str, iterable of Hashable, ..., or None, optional
            Dimensions to reduce. None or ``...`` reduces all dimensions.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        ddof : int, optional
            Delta degrees of freedom; the divisor is ``N - ddof``.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.
        partition_dim : Hashable or {"auto"} or None, optional
            Partition placement after reducing the active partition dimension.

        Returns
        -------
        MPIXarray
            Reduced object with ``.meta`` updated.
        """
        return self._dispatch(
            "std",
            dim,
            skipna=skipna,
            ddof=ddof,
            keep_attrs=keep_attrs,
            partition_dim=partition_dim,
        )

    # -- Groupby (xarray-styled entry points; groupby_reduce/resample_reduce
    #    are internal engine dispatch names, not part of this public surface) -

    def groupby(self, dim: Hashable, labels: xr.DataArray | np.ndarray) -> MPIGroupBy:
        """Group by ``labels`` along ``dim``, mirroring ``xarray.Dataset.groupby``.

        Unlike plain ``xarray`` groupby, this does not return an iterable
        of ``(label, subset)`` pairs -- only a reduction over each group is
        supported. Call a reduction method on the returned handle, e.g.
        ``ds.groupby("time", year).mean()``.

        Parameters
        ----------
        dim : Hashable
            Dimension being grouped and reduced.
        labels : array-like
            Group key for every position along this rank's local ``dim`` axis.

        Returns
        -------
        MPIGroupBy
            Chainable handle; call ``.sum()``, ``.mean()``, ``.count()``,
            ``.min()``, or ``.max()`` on it to get the reduced
            :class:`MPIXarray`.
        """
        return MPIGroupBy(self, dim, labels)

    def resample(self, dim: Hashable, freq: str) -> MPIResample:
        """Resample a datetime dimension to ``freq``, mirroring ``xarray``'s
        ``.resample(...)``.

        Parameters
        ----------
        dim : Hashable
            Datetime dimension to resample.
        freq : str
            Pandas offset alias (e.g. "D", "MS", "YS").

        Returns
        -------
        MPIResample
            Chainable handle; call ``.sum()``, ``.mean()``, ``.count()``,
            ``.min()``, or ``.max()`` on it to get the reduced
            :class:`MPIXarray`.
        """
        return MPIResample(self, dim, freq)

    # -- Arithmetic ------------------------------------------------------------

    def align(
        self,
        other: MPIXarray | xr.Dataset | xr.DataArray,
        dim: Hashable | Literal["auto"] | None = None,
        *,
        chunk_info: Mapping[str, int] | None = None,
        log_partitions: bool = False,
    ) -> tuple[MPIXarray, MPIXarray]:
        """Return ``(self, other)`` partitioned identically across ranks.

        Parameters
        ----------
        other : MPIXarray, xarray.Dataset, or xarray.DataArray
            Operand to align against ``self``.
        dim : Hashable or {"auto"} or None, optional
            Dimension to distribute both operands along when neither is yet
            distributed. Required in that case; ignored otherwise.
        chunk_info : mapping, optional
            Forwarded to ``repartition`` when neither operand is yet distributed.
        log_partitions : bool, optional
            Forwarded to ``repartition`` when neither operand is yet distributed.

        Returns
        -------
        tuple of MPIXarray
            ``(left, right)``, each with matching distribution metadata.
        """
        left, right = self._ops.align(
            self._prepare(),
            _unwrap(other),
            dim,
            chunk_info=chunk_info,
            log_partitions=log_partitions,
        )
        return _finalize(left, self._runtime), _finalize(right, self._runtime)

    def apply(self, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """Call ``func(*args, **kwargs)`` rank-locally, propagating MPI metadata.

        Any :class:`MPIXarray` found in ``args``/``kwargs`` is unwrapped to
        its underlying data (with ``.meta`` reattached) before the call.
        ``func`` must be partition-preserving; see
        :meth:`.operator.Arithmetic.apply` for the exact contract.

        Parameters
        ----------
        func : callable
            Partition-preserving, rank-local function of ``args``/``kwargs``.
        *args : Any
            Positional arguments to ``func``.
        **kwargs : Any
            Keyword arguments to ``func``.

        Returns
        -------
        MPIXarray or Any
            ``func``'s result, wrapped if it is an xarray Dataset/DataArray,
            otherwise returned as-is.
        """
        unwrapped_args = tuple(_unwrap(arg) for arg in args)
        unwrapped_kwargs = {name: _unwrap(value) for name, value in kwargs.items()}
        result = self._ops.apply(func, *unwrapped_args, **unwrapped_kwargs)
        return _finalize(result, self._runtime)

    def matmul(self, right: MPIXarray | Any) -> MPIXarray:
        """Matrix multiplication (``self @ right``), correct under MPI.

        Parameters
        ----------
        right : MPIXarray or Any
            Right operand: an xarray DataArray (distributed or not, wrapped
            or not) or a plain array/scalar.

        Returns
        -------
        MPIXarray
            The matrix product. Replicated (``.meta`` is None) if the
            distributed dimension was contracted away.
        """
        result = self._ops.matmul(self._prepare(), _unwrap(right))
        return _finalize(result, self._runtime)

    def halo_exchange(
        self, dim: Hashable | None = None, *, before: int, after: int
    ) -> tuple[MPIXarray, int, int]:
        """Pad with boundary slices fetched from the adjacent ranks.

        Parameters
        ----------
        dim : Hashable, optional
            Must equal ``self``'s active partition dimension if given;
            defaults to it.
        before : int
            Number of elements requested from the left neighbor.
        after : int
            Number of elements requested from the right neighbor.

        Returns
        -------
        tuple[MPIXarray, int, int]
            ``(padded, left_pad, right_pad)``.
        """
        padded, left_pad, right_pad = self._ops.halo_exchange(
            self._prepare(), dim, before=before, after=after
        )
        return _finalize(padded, self._runtime), left_pad, right_pad

    def rolling_reduce(
        self,
        dim: Hashable,
        window: int,
        reduce: str = "mean",
        *,
        center: bool = True,
        min_periods: int | None = None,
    ) -> MPIXarray:
        """Windowed reduction along ``dim``, correct when ``dim`` is distributed.

        Parameters
        ----------
        dim : Hashable
            Dimension to roll over.
        window : int
            Window size, as in ``xarray.DataArray.rolling``.
        reduce : str, optional
            Name of the reduction to call on the rolling object (e.g.
            "mean", "sum", "min", "max", "std").
        center : bool, optional
            As in ``xarray.DataArray.rolling``.
        min_periods : int or None, optional
            As in ``xarray.DataArray.rolling``.

        Returns
        -------
        MPIXarray
            Rolled-and-reduced object with ``.meta`` preserved.
        """
        result = self._ops.rolling_reduce(
            self._prepare(), dim, window, reduce, center=center, min_periods=min_periods
        )
        return _finalize(result, self._runtime)

    def rolling(
        self,
        dim: Hashable,
        window: int,
        *,
        center: bool = True,
        min_periods: int | None = None,
    ) -> MPIRolling:
        """Windowed rolling handle, mirroring ``xarray.DataArray.rolling``.

        Correct even when ``dim`` is the active partition dimension (see
        :meth:`rolling_reduce`). Call a reduction method on the returned
        handle, e.g. ``ds.rolling("time", 5).mean()``.

        Parameters
        ----------
        dim : Hashable
            Dimension to roll over.
        window : int
            Window size, as in ``xarray.DataArray.rolling``.
        center : bool, optional
            As in ``xarray.DataArray.rolling``.
        min_periods : int or None, optional
            As in ``xarray.DataArray.rolling``.

        Returns
        -------
        MPIRolling
            Chainable handle; call ``.mean()``, ``.sum()``, ``.min()``,
            ``.max()``, ``.std()``, or ``.count()`` on it to get the
            rolled-and-reduced :class:`MPIXarray`.
        """
        return MPIRolling(self, dim, window, center=center, min_periods=min_periods)

    def evaluate(self, expression: str, /, **variables: Any) -> Any:
        """Evaluate a string expression, respecting normal operator precedence.

        Any :class:`MPIXarray` found in ``variables`` is unwrapped to its
        underlying data (with ``.meta`` reattached) before evaluation.

        Parameters
        ----------
        expression : str
            A Python expression referencing ``variables`` by name, e.g.
            ``"(a + b) * c - d / e"``.
        **variables : Any
            Values bound to the names used in ``expression``.

        Returns
        -------
        MPIXarray or Any
            The expression's value, wrapped if it is an xarray
            Dataset/DataArray, otherwise returned as-is.
        """
        unwrapped = {name: _unwrap(value) for name, value in variables.items()}
        result = self._ops.evaluate(expression, **unwrapped)
        return _finalize(result, self._runtime)

    # -- Elementwise, scan, and gather-based operations -------------------

    def where(
        self,
        cond: MPIXarray | xr.Dataset | xr.DataArray | Any,
        other: MPIXarray | xr.Dataset | xr.DataArray | Any = _WHERE_UNSET,
        *,
        drop: bool = False,
    ) -> MPIXarray:
        """Elementwise selection, mirroring ``xarray.DataArray.where``.

        Parameters
        ----------
        cond : MPIXarray, xarray.Dataset, xarray.DataArray, or Any
            Boolean condition, following ``xarray.DataArray.where``.
        other : MPIXarray, xarray.Dataset, xarray.DataArray, or Any, optional
            Fill value where ``cond`` is False. Omit for xarray's default
            (NaN).
        drop : bool, optional
            Must be False when ``self`` is distributed; ``drop=True`` can
            remove a different number of positions on different ranks.

        Returns
        -------
        MPIXarray
            The selected object, with ``.meta`` unchanged.
        """
        args = (cond,) if other is _WHERE_UNSET else (cond, other)
        return self._dispatch("where", *(_unwrap(arg) for arg in args), drop=drop)

    def cumsum(
        self,
        dim: Hashable,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
    ) -> MPIXarray:
        """Cumulative sum along ``dim``, correct when ``dim`` is distributed.

        Parameters
        ----------
        dim : Hashable
            Dimension to accumulate along.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.

        Returns
        -------
        MPIXarray
            Cumulative sum with ``.meta`` unchanged.
        """
        return self._dispatch("cumsum", dim, skipna=skipna, keep_attrs=keep_attrs)

    def median(
        self,
        dim: Hashable,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
    ) -> MPIXarray:
        """Median over ``dim``, correct when ``dim`` is distributed.

        When ``dim`` is the active partition dimension, this gathers the
        full dimension onto every rank (``MPI_Allgather``) and reduces
        locally, since median has no MPI reduction operator the way
        sum/min/max do -- exact, but not memory-scalable for a large
        partition dimension. Unlike :meth:`mean`/:meth:`sum`/etc., only a
        single dimension is supported (not an iterable, ``None``, or ``...``).

        Parameters
        ----------
        dim : Hashable
            Dimension to reduce.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.

        Returns
        -------
        MPIXarray
            Reduced object. Replicated (``.meta`` is None) if ``dim`` was
            the active partition dimension.
        """
        return self._dispatch("median", dim, skipna=skipna, keep_attrs=keep_attrs)

    def diff(
        self,
        dim: Hashable,
        n: int = 1,
        *,
        label: Literal["upper", "lower"] = "upper",
    ) -> MPIXarray:
        """``n``-th order difference along ``dim``.

        Only implemented when ``dim`` is not the active partition
        dimension; see :func:`~.elementwise.Elementwise.diff` for why the
        partition-dimension case is not (it raises ``NotImplementedError``
        rather than silently computing a value that is wrong at every rank
        boundary).

        Parameters
        ----------
        dim : Hashable
            Dimension to difference along.
        n : int, optional
            Order of the difference.
        label : {"upper", "lower"}, optional
            As in ``xarray.DataArray.diff``.

        Returns
        -------
        MPIXarray
            The differenced object, ``n`` elements shorter along ``dim``.
        """
        return self._dispatch("diff", dim, n, label=label)


class MPIRolling:
    """Chainable rolling-window handle, mirroring ``xarray``'s ``.rolling(...)``.

    Returned by :meth:`MPIXarray.rolling`; call one of the reduction
    methods below to compute the windowed reduction via
    :meth:`MPIXarray.rolling_reduce`.

    Parameters
    ----------
    parent : MPIXarray
        Object to roll over.
    dim : Hashable
        Dimension to roll over.
    window : int
        Window size, as in ``xarray.DataArray.rolling``.
    center : bool, optional
        As in ``xarray.DataArray.rolling``.
    min_periods : int or None, optional
        As in ``xarray.DataArray.rolling``.
    """

    def __init__(
        self,
        parent: MPIXarray,
        dim: Hashable,
        window: int,
        *,
        center: bool = True,
        min_periods: int | None = None,
    ) -> None:
        self._parent = parent
        self._dim = dim
        self._window = window
        self._center = center
        self._min_periods = min_periods

    def _reduce(self, reduce: str) -> MPIXarray:
        return self._parent.rolling_reduce(
            self._dim,
            self._window,
            reduce,
            center=self._center,
            min_periods=self._min_periods,
        )

    def mean(self) -> MPIXarray:
        """Rolling mean. See :meth:`MPIXarray.rolling_reduce`."""
        return self._reduce("mean")

    def sum(self) -> MPIXarray:
        """Rolling sum. See :meth:`MPIXarray.rolling_reduce`."""
        return self._reduce("sum")

    def min(self) -> MPIXarray:
        """Rolling minimum. See :meth:`MPIXarray.rolling_reduce`."""
        return self._reduce("min")

    def max(self) -> MPIXarray:
        """Rolling maximum. See :meth:`MPIXarray.rolling_reduce`."""
        return self._reduce("max")

    def std(self) -> MPIXarray:
        """Rolling standard deviation. See :meth:`MPIXarray.rolling_reduce`."""
        return self._reduce("std")

    def count(self) -> MPIXarray:
        """Rolling valid-value count. See :meth:`MPIXarray.rolling_reduce`."""
        return self._reduce("count")


class MPIGroupBy:
    """Chainable groupby handle, mirroring ``xarray``'s ``.groupby(...)``.

    Returned by :meth:`MPIXarray.groupby`; call one of the reduction
    methods below to compute the grouped reduction via the internal
    ``groupby_reduce`` engine dispatch.

    Parameters
    ----------
    parent : MPIXarray
        Object being grouped.
    dim : Hashable
        Dimension being grouped and reduced.
    labels : array-like
        Group key for every position along this rank's local ``dim`` axis.
    """

    def __init__(
        self, parent: MPIXarray, dim: Hashable, labels: xr.DataArray | np.ndarray
    ) -> None:
        self._parent = parent
        self._dim = dim
        self._labels = labels

    def _reduce(
        self,
        op: Literal["sum", "mean", "count", "min", "max"],
        *,
        skipna: bool | None,
        keep_attrs: bool | None,
        partition_dim: Hashable | Literal["auto"] | None,
    ) -> MPIXarray:
        return self._parent._dispatch(
            "groupby_reduce",
            self._dim,
            self._labels,
            op,
            skipna=skipna,
            keep_attrs=keep_attrs,
            partition_dim=partition_dim,
        )

    def sum(
        self,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Sum within each group. See :meth:`MPIXarray.groupby`."""
        return self._reduce(
            "sum", skipna=skipna, keep_attrs=keep_attrs, partition_dim=partition_dim
        )

    def mean(
        self,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Mean within each group. See :meth:`MPIXarray.groupby`."""
        return self._reduce(
            "mean", skipna=skipna, keep_attrs=keep_attrs, partition_dim=partition_dim
        )

    def count(
        self,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Valid-value count within each group. See :meth:`MPIXarray.groupby`."""
        return self._reduce(
            "count", skipna=skipna, keep_attrs=keep_attrs, partition_dim=partition_dim
        )

    def min(
        self,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Minimum within each group. See :meth:`MPIXarray.groupby`."""
        return self._reduce(
            "min", skipna=skipna, keep_attrs=keep_attrs, partition_dim=partition_dim
        )

    def max(
        self,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Maximum within each group. See :meth:`MPIXarray.groupby`."""
        return self._reduce(
            "max", skipna=skipna, keep_attrs=keep_attrs, partition_dim=partition_dim
        )


class MPIResample:
    """Chainable resample handle, mirroring ``xarray``'s ``.resample(...)``.

    Returned by :meth:`MPIXarray.resample`; call one of the reduction
    methods below to compute the resampled reduction via the internal
    ``resample_reduce`` engine dispatch.

    Parameters
    ----------
    parent : MPIXarray
        Object being resampled.
    dim : Hashable
        Datetime dimension to resample.
    freq : str
        Pandas offset alias (e.g. "D", "MS", "YS").
    """

    def __init__(self, parent: MPIXarray, dim: Hashable, freq: str) -> None:
        self._parent = parent
        self._dim = dim
        self._freq = freq

    def _reduce(
        self,
        op: Literal["sum", "mean", "count", "min", "max"],
        *,
        skipna: bool | None,
        keep_attrs: bool | None,
        partition_dim: Hashable | Literal["auto"] | None,
    ) -> MPIXarray:
        return self._parent._dispatch(
            "resample_reduce",
            self._dim,
            self._freq,
            op,
            skipna=skipna,
            keep_attrs=keep_attrs,
            partition_dim=partition_dim,
        )

    def sum(
        self,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Sum within each resampled bin. See :meth:`MPIXarray.resample`."""
        return self._reduce(
            "sum", skipna=skipna, keep_attrs=keep_attrs, partition_dim=partition_dim
        )

    def mean(
        self,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Mean within each resampled bin. See :meth:`MPIXarray.resample`."""
        return self._reduce(
            "mean", skipna=skipna, keep_attrs=keep_attrs, partition_dim=partition_dim
        )

    def count(
        self,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Valid-value count within each resampled bin.

        See :meth:`MPIXarray.resample`.
        """
        return self._reduce(
            "count", skipna=skipna, keep_attrs=keep_attrs, partition_dim=partition_dim
        )

    def min(
        self,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Minimum within each resampled bin. See :meth:`MPIXarray.resample`."""
        return self._reduce(
            "min", skipna=skipna, keep_attrs=keep_attrs, partition_dim=partition_dim
        )

    def max(
        self,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
        partition_dim: Hashable | Literal["auto"] | None = "auto",
    ) -> MPIXarray:
        """Maximum within each resampled bin. See :meth:`MPIXarray.resample`."""
        return self._reduce(
            "max", skipna=skipna, keep_attrs=keep_attrs, partition_dim=partition_dim
        )


def _finalize(result: Any, runtime: MPIRuntime) -> Any:
    """Wrap an ``_MPIXarrayOps`` result in :class:`MPIXarray`.

    ``MPIXarray.__init__`` does the actual popping of ``mpi_meta`` out of
    ``.attrs`` and into ``.meta``. A result that is not an xarray
    Dataset/DataArray (e.g. a plain scalar from :meth:`MPIXarray.apply`/
    :meth:`MPIXarray.evaluate`) passes through unchanged.

    Parameters
    ----------
    result : Any
        Return value of an :class:`~.ops._MPIXarrayOps` method.
    runtime : MPIRuntime
        Runtime the new :class:`MPIXarray` is bound to.

    Returns
    -------
    MPIXarray or Any
        ``result`` wrapped in :class:`MPIXarray` if it is an xarray
        Dataset/DataArray, otherwise ``result`` itself.
    """
    if isinstance(result, (xr.Dataset, xr.DataArray)):
        return MPIXarray(result, runtime)
    return result


def _unwrap(value: Any) -> Any:
    """Return an :class:`MPIXarray` operand ready for ``_MPIXarrayOps``.

    ``value.meta`` is reattached to ``value.data`` (via
    :meth:`MPIXarray._prepare`) so the underlying engine sees the same
    ``.attrs``-embedded metadata it always has. Anything that is not an
    :class:`MPIXarray` passes through unchanged.

    Parameters
    ----------
    value : Any
        Candidate operand, possibly an :class:`MPIXarray`.

    Returns
    -------
    Any
        ``value._prepare()`` if ``value`` is an :class:`MPIXarray`,
        otherwise ``value``.
    """
    return value._prepare() if isinstance(value, MPIXarray) else value
