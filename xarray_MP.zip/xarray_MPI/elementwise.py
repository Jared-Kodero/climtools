"""MPI-aware elementwise, scan, and order-statistic operations.

New primitives that do not fit either existing shape in :mod:`.operator`:

- :meth:`Elementwise.where` is strictly partition-preserving and
  elementwise, so it is implemented the same way
  :meth:`~.operator.Arithmetic.apply` would run it, with one extra check
  ``apply`` cannot express: ``drop=True`` is refused on distributed data,
  since it can remove a different number of positions on different ranks.
- :meth:`Elementwise.cumsum` is partition-preserving in *length* (every
  rank keeps its own local length) but is not partition-preserving in
  *value*: each rank's running total must start from every earlier rank's
  total. That needs a rank-ordered prefix, which this builds the same way
  :func:`~.io.IO.attach_save_chunks` builds its save-chunk plan: rank 0
  gathers every rank's local total (:meth:`~..mpi.runtime.MPIRuntime.gather`),
  computes each rank's exclusive prefix locally, and scatters one prefix
  back to each rank (:meth:`~..mpi.runtime.MPIRuntime.scatter`) -- no new
  MPI collective, just the ``gather``/``scatter`` pair
  :class:`~..mpi.runtime.MPIRuntime` already provides.
- :meth:`Elementwise.median` genuinely reduces the partition dimension
  away, like :mod:`.reductions`, but has no associative MPI reduction
  operator the way sum/min/max do. It gathers every rank's slice onto
  rank 0 (:meth:`~..mpi.runtime.MPIRuntime.gather`), which alone
  reconstructs the full dimension and takes xarray's own median, then
  broadcasts the (already-reduced, small) result back
  (:meth:`~..mpi.runtime.MPIRuntime.broadcast`) -- correct, and only rank 0
  ever materializes the full dimension, unlike an ``Allgather`` that would
  replicate it onto every rank.
- :meth:`Elementwise.diff` is only implemented when the diffed dimension
  is *not* the active partition dimension (a plain rank-local call).
  Diffing along the partition dimension shortens the global dimension by
  ``n`` at one global edge, which means every rank's ``start``/``stop``/
  ``global_size`` would need recomputing -- not just ``n`` boundary values
  borrowed from a neighbor the way :meth:`~.operator.Arithmetic.halo_exchange`
  provides for :meth:`~.operator.Arithmetic.rolling_reduce`. That
  redistribution step is not implemented; the method raises
  ``NotImplementedError`` rather than silently computing a value that is
  wrong at every rank boundary.

Mixed into :class:`~.ops._MPIXarrayOps` alongside
:class:`~.operator.Arithmetic`; requires the ``self._runtime`` attribute
(and its ``gather``/``scatter``/``broadcast``/``is_root`` methods) and the
``self._check_operands_distribution``/``self._check_partition_preserved``/
``self._reattach_meta``/``self._agree`` helpers :class:`~.operator.Arithmetic`
and :class:`~.engine.ReductionPlanningMixin` define.

Collective error-safety note
-----------------------------
:mod:`.engine`'s ``Allreduce``-based reductions guard every collective with
``_guarded``/``raise_if_error`` so one rank's local exception cannot leave
the others blocked in a collective they will now never receive.
:class:`~..mpi.runtime.MPIRuntime`'s ``gather``/``scatter``/``broadcast``
(used below) are thin, unguarded wrappers around ``mpi4py``'s pickle-based
collectives with no such synchronization. Treat this as a known follow-up,
not a resolved concern.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

import xarray as xr

from .meta import get_mpi_meta, strip_mpi_meta

if TYPE_CHECKING:
    from collections.abc import Hashable

#: Sentinel distinguishing "no fill value given" from a genuine ``other=None``.
_UNSET = object()


class Elementwise:
    """Elementwise, scan, and gather-based operations for distributed xarray objects.

    Assumes the host class provides ``self._runtime`` (with its
    ``gather``/``scatter``/``broadcast``/``is_root`` methods) and the
    ``self._check_operands_distribution``, ``self._check_partition_preserved``,
    ``self._reattach_meta``, ``self._agree`` helpers defined on
    :class:`~.operator.Arithmetic`/:class:`~.engine.ReductionPlanningMixin`;
    provided by :class:`~.ops._MPIXarrayOps`.
    """

    def where(
        self,
        value: xr.Dataset | xr.DataArray,
        cond: Any,
        other: Any = _UNSET,
        *,
        drop: bool = False,
    ) -> xr.Dataset | xr.DataArray:
        """Elementwise selection (``value.where(cond, other)``), MPI-safe.

        Parameters
        ----------
        value : xarray.Dataset or xarray.DataArray
            Object to select from.
        cond : Any
            Boolean condition, following ``xarray.DataArray.where``.
        other : Any, optional
            Fill value where ``cond`` is False. Omit for xarray's default
            (NaN).
        drop : bool, optional
            Must be False for a distributed object.

        Returns
        -------
        xarray.Dataset or xarray.DataArray
            The selected object, with ``.meta`` preserved unchanged.

        Raises
        ------
        ValueError
            If ``drop=True`` is requested on a distributed object, or the
            operands are distributed over incompatible partitions (see
            :meth:`~.operator.Arithmetic.apply`).
        """
        operands = (value, cond) if other is _UNSET else (value, cond, other)
        meta, reference = self._check_operands_distribution(operands)
        if meta is not None and drop:
            raise ValueError(
                "where(): drop=True is not supported on a distributed "
                + "object; it can remove a different number of positions on "
                + "different ranks and desynchronize the partition. Select "
                + "with isel()/sel() first, or repartition afterwards."
            )

        self._agree(
            (
                "where",
                None if meta is None else (str(meta["dim"]), int(meta["global_size"])),
            )
        )
        result = value.where(cond) if other is _UNSET else value.where(cond, other)
        if meta is None:
            return result
        self._check_partition_preserved(result, meta, reference)
        return self._reattach_meta(result, meta)

    def cumsum(
        self,
        value: xr.Dataset | xr.DataArray,
        dim: Hashable,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
    ) -> xr.Dataset | xr.DataArray:
        """Cumulative sum along ``dim``, correct when ``dim`` is distributed.

        When ``dim`` is the active partition dimension, each rank's running
        total must include every earlier rank's total. This gathers every
        rank's local total onto rank 0, which computes each rank's
        *exclusive* prefix (the sum of every rank before it) and scatters
        one prefix back to each rank; every rank then adds its prefix onto
        its own local cumulative sum. No new MPI collective: just the
        ``gather``/``scatter`` pair already used elsewhere in this package
        (see :func:`~.io.IO.attach_save_chunks`).

        Parameters
        ----------
        value : xarray.Dataset or xarray.DataArray
            Object to accumulate.
        dim : Hashable
            Dimension to accumulate along.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics. Applied
            consistently to both the local cumulative sum and the local
            total that feeds the cross-rank prefix, so a rank's NaNs never
            change another rank's prefix.
        keep_attrs : bool or None, optional
            Whether to preserve attributes on the rank-local cumulative sum
            step; lost by the subsequent addition of the cross-rank prefix.

        Returns
        -------
        xarray.Dataset or xarray.DataArray
            Cumulative sum with the same local length and ``.meta`` as
            ``value``.
        """
        meta = get_mpi_meta(value)
        if meta is None or meta["dim"] != dim:
            return value.cumsum(dim, skipna=skipna, keep_attrs=keep_attrs)

        self._agree(("cumsum", str(dim), int(meta["global_size"])))
        local_cumsum = value.cumsum(dim, skipna=skipna, keep_attrs=keep_attrs)
        local_total = value.sum(dim, skipna=skipna)

        totals = self._runtime.gather(local_total, root=0)
        prefixes = None
        if self._runtime.is_root():
            prefixes = []
            running = totals[0] * 0
            for total in totals:
                prefixes.append(running)
                running = running + total
        exclusive_prefix = self._runtime.scatter(prefixes, root=0)

        result = local_cumsum + exclusive_prefix
        return self._reattach_meta(result, meta)

    def median(
        self,
        value: xr.Dataset | xr.DataArray,
        dim: Hashable,
        *,
        skipna: bool | None = None,
        keep_attrs: bool | None = None,
    ) -> xr.Dataset | xr.DataArray:
        """Median over ``dim``, correct when ``dim`` is distributed.

        Median has no MPI reduction operator (unlike sum/min/max), so when
        ``dim`` is the active partition dimension this gathers every
        rank's slice onto rank 0, which reconstructs the full ``dim`` and
        takes xarray's own median locally, then broadcasts the (already
        reduced, small) result back to every rank. Only rank 0 ever
        materializes the full ``dim`` -- unlike an ``Allgather``, which
        would replicate it onto every rank.

        Parameters
        ----------
        value : xarray.Dataset or xarray.DataArray
            Object to reduce. Unlike :meth:`~.core.MPIXarray.mean`,
            :meth:`~.core.MPIXarray.sum`, etc., only a single dimension is
            supported (not an iterable, ``None``, or ``...``).
        dim : Hashable
            Dimension to reduce.
        skipna : bool or None, optional
            Missing-value behavior, following xarray semantics.
        keep_attrs : bool or None, optional
            Whether to preserve attributes.

        Returns
        -------
        xarray.Dataset or xarray.DataArray
            Reduced object. Replicated (``.meta`` is None) if ``dim`` was
            the active partition dimension; otherwise ``.meta`` is
            preserved unchanged.
        """
        meta = get_mpi_meta(value)
        if meta is None or meta["dim"] != dim:
            return value.median(dim, skipna=skipna, keep_attrs=keep_attrs)

        self._agree(("median", str(dim), int(meta["global_size"])))
        pieces = self._runtime.gather(value, root=0)
        result = None
        if self._runtime.is_root():
            full = (
                xr.concat(pieces, dim=dim, data_vars="minimal")
                if isinstance(value, xr.Dataset)
                else xr.concat(pieces, dim=dim)
            )
            result = full.median(dim, skipna=skipna, keep_attrs=keep_attrs)
        result = self._runtime.broadcast(result, root=0)
        return strip_mpi_meta(result)

    def diff(
        self,
        value: xr.Dataset | xr.DataArray,
        dim: Hashable,
        n: int = 1,
        *,
        label: Literal["upper", "lower"] = "upper",
    ) -> xr.Dataset | xr.DataArray:
        """``n``-th order difference along ``dim``.

        Only implemented when ``dim`` is not the active partition
        dimension, in which case this is a plain rank-local
        ``value.diff(...)``.

        Parameters
        ----------
        value : xarray.Dataset or xarray.DataArray
            Object to difference.
        dim : Hashable
            Dimension to difference along.
        n : int, optional
            Order of the difference.
        label : {"upper", "lower"}, optional
            As in ``xarray.DataArray.diff``.

        Returns
        -------
        xarray.Dataset or xarray.DataArray
            The differenced object, ``n`` elements shorter along ``dim``.

        Raises
        ------
        NotImplementedError
            If ``dim`` is the active partition dimension.
        """
        meta = get_mpi_meta(value)
        if meta is None or meta["dim"] != dim:
            return value.diff(dim, n=n, label=label)
        raise NotImplementedError(
            f"diff() along the active MPI partition dimension {dim!r} is "
            + "not implemented: it shortens the global dimension by n at one "
            + "global edge, which requires recomputing every rank's "
            + "start/stop/global_size, not just borrowing n boundary values "
            + "with halo_exchange(). Repartition onto a different dimension "
            + f"first, or call .data.diff({dim!r}, n={n!r}) for a rank-local "
            + "result that is mathematically wrong at every rank boundary."
        )
