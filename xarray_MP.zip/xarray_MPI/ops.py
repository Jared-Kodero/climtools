"""Internal MPI-aware xarray engine.

:class:`_MPIXarrayOps` composes, by concern, the numerical/collective
implementation used by :class:`~.core.MPIXarray`:

- :mod:`.common`      Communicator-free constants and dtype helpers.
- :mod:`.engine`      Rank-independent reduction planning and MPI collective
  primitives shared by every reduction.
- :mod:`.io`          Dataset/DataArray open, distribute, repartition,
  create, and save-chunk attachment.
- :mod:`.indexing`    Global-coordinate ``isel``/``sel``.
- :mod:`.reductions`  ``sum``/``prod``/``mean``/``min``/``max``/``first``/
  ``last``/``any``/``all``.
- :mod:`.statistics`  ``std``/``var``.
- :mod:`.groupby`     ``groupby_reduce``/``resample_reduce``.
- :mod:`.operator`    ``align``/``apply``/``evaluate`` -- rank-local
  arithmetic restricted to partition-preserving operations, plus an
  ``ast``-based expression evaluator built on top of ``apply``; and the
  dedicated implementations for the operations that legitimately need to
  reduce or communicate across the partition dimension: ``matmul``
  (MPI-reduced distributed matrix multiplication) and
  ``rolling_reduce``/``halo_exchange`` (windowed reductions via
  point-to-point boundary exchange with the adjacent ranks).
- :mod:`.elementwise` ``where``/``cumsum``/``median``/``diff`` -- new
  primitives that fit neither the ``apply()`` nor the ``Allreduce``-based
  reduction shape; see the module docstring for why each needs its own
  strategy.

Every method here takes the ``xarray.Dataset``/``xarray.DataArray`` to act
on explicitly as its first argument, reads/writes ``mpi_meta`` on that
object's ``.attrs``, and returns a raw xarray object still carrying it.
This module is private: :class:`~.core.MPIXarray` is the public interface,
and is the only thing that should hold onto a runtime and call these.
"""

from __future__ import annotations

from ..mpi.runtime import MPIRuntime
from .elementwise import Elementwise
from .groupby import Groupby
from .indexing import Indexing
from .io import IO
from .operator import Arithmetic
from .reductions import Reduction
from .statistics import Statistics


class _MPIXarrayOps(
    IO, Indexing, Reduction, Statistics, Groupby, Arithmetic, Elementwise
):
    """Internal MPI-aware xarray engine bound to an MPI runtime.

    Composes, by concern, the same seven mixins :class:`~.core.MPIXarray`
    delegates to: :class:`~.io.IO`, :class:`~.indexing.Indexing`,
    :class:`~.reductions.Reduction`, :class:`~.statistics.Statistics`,
    :class:`~.groupby.Groupby`, :class:`~.operator.Arithmetic`,
    :class:`~.elementwise.Elementwise`.

    Parameters
    ----------
    runtime : MPIRuntime
        Runtime whose communicator is used for distributed operations.
    """

    def __init__(self, runtime: MPIRuntime) -> None:
        self._runtime = runtime
